package smart.mirror;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        ActionBar lmao = getSupportActionBar();
        lmao.setTitle("Smart Mirror");
        lmao.setDisplayHomeAsUpEnabled(true);
        ImageView img1 = (ImageView) findViewById(R.id.imageView3);
        ImageView img2 = (ImageView) findViewById(R.id.imageView5);
        ImageView img3 = (ImageView) findViewById(R.id.imageView6);
        img1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity6.this, MainActivity7.class);
                Toast.makeText(MainActivity6.this,
                        R.string.added_toast, Toast.LENGTH_SHORT)
                        .show();
                startActivity(intent1);
            }
        });
        img2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent2 = new Intent(MainActivity6.this, MainActivity8.class);
                Toast.makeText(MainActivity6.this,
                        R.string.added_toast, Toast.LENGTH_SHORT)
                        .show();
                startActivity(intent2);
            }
        });
        img3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent3 = new Intent(MainActivity6.this, MainActivity3.class);
                Toast.makeText(MainActivity6.this,
                        R.string.added_toast, Toast.LENGTH_SHORT)
                        .show();
                startActivity(intent3);
            }
        });
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}