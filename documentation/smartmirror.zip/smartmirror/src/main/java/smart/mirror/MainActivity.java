package smart.mirror;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        ActionBar lmao = getSupportActionBar();
        lmao.setTitle("Smart Mirror");
        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final EditText something = (EditText) findViewById(R.id.editText);
                final String input = something.getText().toString();
                final EditText something1 = (EditText) findViewById(R.id.editText2);
                final String input1 = something1.getText().toString();
                if (input.length() == 0) {
                    something.requestFocus();
                    something.setError("PLEASE PROVIDE YOUR EMAIL OR USERNAME");
                } else if (input1.length() == 0) {
                    something1.requestFocus();
                    something1.setError("PLEASE PROVIDE YOUR PASSWORD");
                } else {
                    Intent intent = new Intent(MainActivity.this, Demo.class);
                    startActivity(intent);
                }
            }
        });
    }


    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }*/
}
